
File named sdk+version, for example `iphoneos13.2.tar.bz` come here.
```
xcodebuild -showsdks
```
